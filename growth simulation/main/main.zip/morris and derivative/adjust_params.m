% adjust parameters
global r1 r2 m1 m2 Kc1 Kn1 Kp1 Kn2 Kp2 Re1 NPh Nf Pf Q1c Q1n Q1p Q2c Q2n Q2p
global ga1 ga2 pH0


main
